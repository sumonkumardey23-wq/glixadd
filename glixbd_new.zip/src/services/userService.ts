import { doc, getDoc, setDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '@/src/lib/firebase';
import { User } from 'firebase/auth';

export const ensureUserDocument = async (user: User) => {
  try {
    const userRef = doc(db, 'users', user.uid);
    const userDoc = await getDoc(userRef);
    
    if (!userDoc.exists()) {
      await setDoc(userRef, {
        uid: user.uid,
        name: user.displayName || 'Unnamed User',
        email: user.email,
        phone: user.phoneNumber || '',
        walletBalance: 0,
        points: 0,
        isBlocked: false,
        createdAt: serverTimestamp()
      }, { merge: true });
    }
  } catch (err) {
    console.error("Error ensuring user document:", err);
  }
};
