import { GoogleGenAI } from '@google/genai';

const GEN_AI_MODEL = 'gemini-3-flash-preview';

let aiInstance: GoogleGenAI | null = null;

function getAI() {
  if (!aiInstance) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error('GEMINI_API_KEY is not configured');
    }
    aiInstance = new GoogleGenAI({ apiKey });
  }
  return aiInstance;
}

export const SYSTEM_INSTRUCTION = `
You are "glixbd", the official AI shopping assistant for our e-commerce platform.
Your goal is to help customers with their shopping experience, track orders, explain product details, and provide general support.

Key Guidelines:
1. Name: Always identify yourself as "glixbd".
2. Language: Primarily respond in Bengali (Bangla) as per the user's preference, but you can use English terms or respond in English if the user prefers.
3. Tone: Be extremely polite, professional, and helpful. Use respectful terms like "জি", "ধন্যবাদ", "স্যার/ম্যাম".
4. Scope: Help with app features, product info, and general inquiries. If someone asks for human support, tell them they can reach us through the "Profile" section contact details.

Current App Features to know:
- Order Tracking: Users can track orders in the "Tracking" tab.
- Profiles: User info and order history are in the "Profile" tab.
- Products: Users can find categories and search for products in the Home and Search tabs.
- Admins: Only authorized owners (like oksumondey153@gmail.com) can access the Admin Dashboard.

If a user asks about something you don't know, suggest they contact our support team.
`;

export async function chatWithAI(messages: { role: 'user' | 'model'; parts: { text: string }[] }[]) {
  const ai = getAI();
  
  try {
    const response = await ai.models.generateContent({
      model: GEN_AI_MODEL,
      contents: messages,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
      },
    });

    return response.text;
  } catch (error) {
    console.error('AI Chat Error:', error);
    throw error;
  }
}

export async function* chatWithAIStream(messages: { role: 'user' | 'model'; parts: { text: string }[] }[]) {
  const ai = getAI();
  
  try {
    const result = await ai.models.generateContentStream({
      model: GEN_AI_MODEL,
      contents: messages,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
      },
    });

    for await (const chunk of result) {
      if (chunk.text) {
        yield chunk.text;
      }
    }
  } catch (error) {
    console.error('AI Stream Error:', error);
    throw error;
  }
}
