import { useState, useEffect } from 'react';
import { db, auth } from '@/src/lib/firebase';
import { doc, getDoc, setDoc, serverTimestamp } from 'firebase/firestore';
import { onAuthStateChanged } from 'firebase/auth';

const ADMIN_EMAIL = 'oksumondey153@gmail.com';

export function useAdmin() {
  const [isAdmin, setIsAdmin] = useState<boolean>(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (user) => {
      if (user) {
        try {
          const adminRef = doc(db, 'admins', user.uid);
          console.log(`Checking admin status for: ${user.email} (${user.uid})`);
          const adminDoc = await getDoc(adminRef);
          
          if (adminDoc.exists()) {
            console.log("Admin document found.");
            setIsAdmin(true);
          } else if (user.email === ADMIN_EMAIL) {
            console.log("Promoting user to admin...");
            // Self-promotion for the owner
            await setDoc(adminRef, {
              email: user.email,
              createdAt: serverTimestamp(),
              isSuperAdmin: true
            });
            console.log("Admin document created successfully.");
            setIsAdmin(true);
          } else {
            console.log("User is not an admin.");
            setIsAdmin(false);
          }
        } catch (err) {
          console.error('Admin check failed:', err);
          setIsAdmin(false);
        }
      } else {
        setIsAdmin(false);
      }
      setLoading(false);
    });
    return unsub;
  }, []);

  return { isAdmin, loading };
}
