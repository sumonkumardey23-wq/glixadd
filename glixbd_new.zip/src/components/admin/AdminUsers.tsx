import React, { useState, useEffect } from 'react';
import { collection, query, getDocs, doc, updateDoc, orderBy } from 'firebase/firestore';
import { db } from '@/src/lib/firebase';
import { UserProfile } from '@/src/types';
import { Search, UserX, UserCheck, MessageSquare } from 'lucide-react';
import { motion } from 'framer-motion';
import { createNotification } from '@/src/services/notificationService';

export default function AdminUsers() {
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [selectedUser, setSelectedUser] = useState<UserProfile | null>(null);
  const [notifText, setNotifText] = useState('');

  const fetchUsers = async () => {
    try {
      const q = query(collection(db, 'users'), orderBy('name', 'asc'));
      const snap = await getDocs(q);
      setUsers(snap.docs.map(d => ({ uid: d.id, ...d.data() } as UserProfile)));
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const toggleBlock = async (user: UserProfile) => {
    try {
      const userRef = doc(db, 'users', user.uid);
      await updateDoc(userRef, { isBlocked: !user.isBlocked });
      fetchUsers();
    } catch (err) {
      console.error(err);
      alert('স্ট্যাটাস আপডেট করতে সমস্যা হয়েছে।');
    }
  };

  const sendDirectNotif = async () => {
    if (!selectedUser || !notifText.trim()) return;
    try {
      await createNotification(selectedUser.uid, {
        title: 'অ্যাডমিন মেসেজ',
        message: notifText,
        type: 'system',
        isRead: false
      });
      setNotifText('');
      setSelectedUser(null);
    } catch (err) {
      console.error(err);
    }
  };

  const filteredUsers = users.filter(u => 
    u.name.toLowerCase().includes(search.toLowerCase()) || 
    u.phone.includes(search)
  );

  if (loading) return <div className="p-8 text-center font-bold">লোড হচ্ছে...</div>;

  return (
    <div className="p-4 lg:p-8 space-y-8">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-text-main">ইউজার ম্যানেজমেন্ট</h1>
          <p className="text-sm text-text-muted">নিবন্ধিত গ্রাহকদের তথ্য ও নিয়ন্ত্রণ</p>
        </div>
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
          <input 
            type="text" 
            placeholder="নাম বা ফোন দিয়ে খুঁজুন..."
            className="pl-12 pr-6 py-3 bg-white border border-gray-100 rounded-2xl w-full lg:w-80 outline-none focus:border-primary transition-all font-bold"
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
        </div>
      </div>

      <div className="bg-white rounded-[32px] border border-gray-100 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-gray-50/50 border-b border-gray-50 text-[10px] uppercase tracking-widest font-black text-text-muted">
                <th className="px-6 py-4">গ্রাহক</th>
                <th className="px-6 py-4">ফোন</th>
                <th className="px-6 py-4">ব্যালেন্স</th>
                <th className="px-6 py-4">স্ট্যাটাস</th>
                <th className="px-6 py-4 text-right">অ্যাকশন</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {filteredUsers.map(user => (
                <tr key={user.uid} className="group hover:bg-gray-50/50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-primary/10 text-primary rounded-xl flex items-center justify-center font-black">
                        {user.name?.[0] || 'U'}
                      </div>
                      <div>
                        <p className="font-bold text-sm">{user.name}</p>
                        <p className="text-[10px] text-text-muted">{user.email || 'ইমেইল নেই'}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 font-bold text-sm">{user.phone}</td>
                  <td className="px-6 py-4 font-bold text-sm text-primary">৳{user.walletBalance || 0}</td>
                  <td className="px-6 py-4">
                    <span className={`text-[10px] font-black px-2 py-0.5 rounded-full ${user.isBlocked ? 'bg-red-50 text-red-500' : 'bg-green-50 text-green-500'}`}>
                      {user.isBlocked ? 'ব্লকড' : 'অ্যাক্টিভ'}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center justify-end gap-2">
                      <button 
                        onClick={() => setSelectedUser(user)}
                        className="p-2 bg-blue-50 text-blue-500 rounded-lg hover:bg-blue-500 hover:text-white transition-all"
                        title="মেসেজ পাঠান"
                      >
                        <MessageSquare size={18} />
                      </button>
                      <button 
                        onClick={() => toggleBlock(user)}
                        className={`p-2 rounded-lg transition-all ${
                          user.isBlocked 
                            ? 'bg-green-50 text-green-500 hover:bg-green-500 hover:text-white' 
                            : 'bg-red-50 text-red-500 hover:bg-red-500 hover:text-white'
                        }`}
                        title={user.isBlocked ? 'আনব্লক করুন' : 'ব্লক করুন'}
                      >
                        {user.isBlocked ? <UserCheck size={18} /> : <UserX size={18} />}
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Message Modal */}
      {selectedUser && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <motion.div 
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-white rounded-[40px] p-8 w-full max-w-md space-y-6 shadow-2xl overflow-hidden relative"
          >
            <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-full -mr-16 -mt-16" />
            
            <div className="space-y-2">
              <h3 className="text-xl font-black">{selectedUser.name}-কে মেসেজ পাঠান</h3>
              <p className="text-sm text-text-muted">গ্রাহকের নোটিফিকেশন সেন্টারে এই মেসেজটি যাবে।</p>
            </div>

            <textarea 
              className="w-full h-32 bg-gray-50 border-2 border-transparent focus:border-primary p-4 rounded-2xl font-bold outline-none transition-all resize-none"
              placeholder="আপনার মেসেজ লিখুন..."
              value={notifText}
              onChange={e => setNotifText(e.target.value)}
            />

            <div className="flex gap-3">
              <button 
                onClick={() => setSelectedUser(null)}
                className="flex-1 py-4 bg-gray-100 rounded-2xl font-black hover:bg-gray-200 transition-colors"
              >
                বাতিল
              </button>
              <button 
                onClick={sendDirectNotif}
                disabled={!notifText.trim()}
                className="flex-1 py-4 bg-primary text-white rounded-2xl font-black shadow-lg shadow-primary/20 hover:scale-105 active:scale-95 transition-all disabled:opacity-50"
              >
                পাঠান
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
