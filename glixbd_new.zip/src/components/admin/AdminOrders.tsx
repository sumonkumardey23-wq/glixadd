import React, { useState, useEffect } from 'react';
import { collection, query, getDocs, doc, updateDoc, orderBy, addDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '@/src/lib/firebase';
import { motion } from 'framer-motion';
import { Package, Search, ExternalLink, Calendar, Truck, CheckCircle, XCircle, Image as ImageIcon, CreditCard } from 'lucide-react';
import { formatPrice, formatDate } from '@/src/lib/utils';
import { OrderStatusLabels } from '@/src/types';
import { createNotification } from '@/src/services/notificationService';
import { getDoc } from 'firebase/firestore';

const StatusDetails: Record<string, { bn: string, message: string, messageBn: string }> = {
  pending: { bn: 'পেন্ডিং', message: 'Order is pending confirmation.', messageBn: 'অর্ডারটি কনফার্মেশনের জন্য অপেক্ষায় আছে।' },
  processing: { bn: 'প্রসেসিং', message: 'Order is being prepared.', messageBn: 'আপনার অর্ডারটি প্যাকেট করা হচ্ছে।' },
  shipped: { bn: 'শিপড', message: 'Order has been handed over to courier.', messageBn: 'আপনার অর্ডারটি কুরিয়ারে হস্তান্তর করা হয়েছে।' },
  delivered: { bn: 'ডেলিভারড', message: 'Order has been delivered.', messageBn: 'আপনার অর্ডারটি সফলভাবে ডেলিভারি করা হয়েছে।' },
  cancelled: { bn: 'ক্যান্সেল', message: 'Order has been cancelled.', messageBn: 'দুঃখিত, আপনার অর্ডারটি বাতিল করা হয়েছে।' },
};

export default function AdminOrders() {
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = async () => {
    setLoading(true);
    try {
      const snap = await getDocs(query(collection(db, 'orders'), orderBy('createdAt', 'desc')));
      setOrders(snap.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const updateStatus = async (orderId: string, newStatus: string) => {
    try {
      const details = StatusDetails[newStatus];
      const docRef = doc(db, 'orders', orderId);
      
      // Update order status
      await updateDoc(docRef, { status: newStatus });
      
      // Add tracking history event
      await addDoc(collection(db, `orders/${orderId}/tracking`), {
        status: newStatus,
        statusBn: details.bn,
        message: details.message,
        messageBn: details.messageBn,
        createdAt: serverTimestamp()
      });

      // Send Notification to user
      const orderSnap = await getDoc(docRef);
      if (orderSnap.exists()) {
        const orderData = orderSnap.data() as any;
        if (orderData.userId) {
          await createNotification(orderData.userId, {
            title: 'অর্ডার আপডেট!',
            message: `আপনার অর্ডার #${orderData.orderNumber} এখন ${details.bn} পর্যায়ে আছে।`,
            type: 'order',
            isRead: false,
            link: `/tracking/${orderData.orderNumber}`
          });
        }
      }

      fetchOrders();
    } catch (err) {
      console.error(err);
      alert('অর্ডার স্ট্যাটাস আপডেট করতে সমস্যা হয়েছে।');
    }
  };

  const filteredOrders = orders.filter(o => 
    o.orderNumber.toLowerCase().includes(searchTerm.toLowerCase()) || 
    o.shippingAddress?.fullName?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-4 lg:p-8 space-y-8">
      <div className="space-y-1">
        <h1 className="text-2xl font-black text-text-main">অর্ডার ম্যানেজমেন্ট</h1>
        <p className="text-sm text-text-muted">সব ইনকমিং অর্ডার ট্র্যাক ও আপডেট করুন</p>
      </div>

      <div className="relative group">
        <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-primary transition-colors" size={20} />
        <input 
          type="text" 
          placeholder="অর্ডার নাম্বার বা কাস্টমার নাম লিখে সার্চ দিন..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full bg-white border border-gray-100 px-14 py-4 rounded-3xl font-bold shadow-sm focus:border-primary outline-none"
        />
      </div>

      {loading ? (
        <div className="p-12 text-center font-bold">লোড হচ্ছে...</div>
      ) : (
        <div className="space-y-6">
          {filteredOrders.map(order => (
            <motion.div 
              layout
              key={order.id}
              className="bg-white p-6 rounded-[32px] border border-gray-100 shadow-sm space-y-6"
            >
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-gray-50 pb-6">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 bg-primary/5 text-primary rounded-2xl flex items-center justify-center">
                    <Package size={28} />
                  </div>
                  <div>
                    <h3 className="font-black text-lg">#{order.orderNumber}</h3>
                    <div className="flex items-center gap-2 text-[10px] text-text-muted font-bold uppercase tracking-wider">
                      <Calendar size={12} />
                      {formatDate(order.createdAt)}
                    </div>
                  </div>
                </div>
                <div className="flex flex-wrap items-center gap-3">
                  <StatusButton 
                    active={order.status === 'pending'} 
                    label="পেন্ডিং" 
                    color="orange"
                    onClick={() => updateStatus(order.id, 'pending')} 
                  />
                  <StatusButton 
                    active={order.status === 'processing'} 
                    label="প্রসেসিং" 
                    color="blue"
                    onClick={() => updateStatus(order.id, 'processing')} 
                  />
                  <StatusButton 
                    active={order.status === 'shipped'} 
                    label="শিপড" 
                    color="purple"
                    onClick={() => updateStatus(order.id, 'shipped')} 
                  />
                  <StatusButton 
                    active={order.status === 'delivered'} 
                    label="ডেলিভারড" 
                    color="green"
                    onClick={() => updateStatus(order.id, 'delivered')} 
                  />
                  <StatusButton 
                    active={order.status === 'cancelled'} 
                    label="ক্যান্সেল" 
                    color="red"
                    onClick={() => updateStatus(order.id, 'cancelled')} 
                  />
                </div>
              </div>

              <div className="grid lg:grid-cols-3 gap-8">
                {/* Customer Info */}
                <div className="space-y-3">
                  <p className="text-[10px] font-black text-text-muted uppercase tracking-widest flex items-center gap-2">
                    <Truck size={12} />
                    শিপিং অ্যাড্রেস
                  </p>
                  <div className="text-sm font-bold space-y-1">
                    <p className="text-text-main text-base">{order.shippingAddress?.fullName}</p>
                    <p className="text-primary font-black">{order.shippingAddress?.phone}</p>
                    <p className="text-text-muted leading-relaxed">
                      {order.shippingAddress?.address}, {order.shippingAddress?.thana}, {order.shippingAddress?.district}
                    </p>
                  </div>
                </div>

                {/* Items */}
                <div className="lg:col-span-2 space-y-4">
                  <p className="text-[10px] font-black text-text-muted uppercase tracking-widest">অর্ডার আইটেম ({order.items?.length || 0})</p>
                  
                  <div className="space-y-3">
                    {order.items?.map((item: any, idx: number) => (
                      <div key={idx} className="flex gap-4 p-3 bg-gray-50 rounded-2xl border border-gray-100 items-center">
                        <div className="w-16 h-16 bg-white rounded-xl overflow-hidden flex-shrink-0 border border-gray-100 flex items-center justify-center">
                          {item.image ? (
                            <img src={item.image} alt={item.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                          ) : (
                            <div className="text-gray-300"><ImageIcon size={20} /></div>
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <h4 className="font-bold text-sm text-text-main truncate">{item.name}</h4>
                          <div className="flex flex-wrap items-center gap-2 mt-1">
                            <p className="text-[10px] font-bold text-text-muted">
                              {formatPrice(item.price)} × {item.quantity} পিস
                            </p>
                            {item.size && (
                              <span className="bg-primary/10 text-primary text-[9px] font-black px-2 py-0.5 rounded-lg uppercase">
                                সাইজ: {item.size}
                              </span>
                            )}
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-black text-primary text-sm">{formatPrice(item.price * item.quantity)}</p>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="bg-primary/5 rounded-2xl p-5 flex flex-col sm:flex-row items-center justify-between gap-4 border border-primary/10 transition-all hover:bg-primary/10">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-primary text-white rounded-xl flex items-center justify-center shadow-lg shadow-primary/20">
                        <CreditCard size={20} />
                      </div>
                      <div>
                        <p className="text-[10px] font-black text-primary uppercase tracking-widest leading-none mb-1">পেমেন্ট মেথড</p>
                        <p className="font-black text-text-main text-sm uppercase">{order.paymentMethod === 'cod' ? 'ক্যাশ অন ডেলিভারি' : 'বিকাশ পেমেন্ট'}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-[10px] font-black text-text-muted uppercase tracking-widest leading-none mb-1">সর্বমোট পেমেন্ট</p>
                      <p className="text-2xl font-black text-primary">{formatPrice(order.total)}</p>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}

function StatusButton({ active, label, onClick, color }: { active: boolean, label: string, onClick: () => void, color: string }) {
  const colors: Record<string, string> = {
    orange: 'bg-orange-50 text-orange-500 border-orange-100',
    blue: 'bg-blue-50 text-blue-500 border-blue-100',
    purple: 'bg-purple-50 text-purple-500 border-purple-100',
    green: 'bg-green-50 text-green-500 border-green-100',
    red: 'bg-red-50 text-red-500 border-red-100'
  };

  const activeColors: Record<string, string> = {
    orange: 'bg-orange-500 text-white shadow-lg shadow-orange-200',
    blue: 'bg-blue-500 text-white shadow-lg shadow-blue-200',
    purple: 'bg-purple-500 text-white shadow-lg shadow-purple-200',
    green: 'bg-green-500 text-white shadow-lg shadow-green-200',
    red: 'bg-red-500 text-white shadow-lg shadow-red-200'
  };

  return (
    <button 
      onClick={onClick}
      className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-wider transition-all border ${active ? activeColors[color] : `bg-white text-text-muted hover:${colors[color]} border-gray-100`}`}
    >
      {label}
    </button>
  );
}
