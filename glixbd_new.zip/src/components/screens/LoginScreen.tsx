import React, { useState } from 'react';
import { auth } from '@/src/lib/firebase';
import { GoogleAuthProvider, signInWithPopup, signInWithEmailAndPassword } from 'firebase/auth';
import { User, LogIn, Mail, Lock, Eye, EyeOff, AlertCircle } from 'lucide-react';
import { useNavigate, NavLink } from 'react-router-dom';
import { motion } from 'framer-motion';

export default function LoginScreen() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleEmailLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      await signInWithEmailAndPassword(auth, formData.email, formData.password);
      navigate('/profile');
    } catch (err: any) {
      console.error(err);
      setError('ইমেল অথবা পাসওয়ার্ড ভুল। আবার চেষ্টা করুন।');
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    if (loading) return;
    setLoading(true);
    setError('');
    const provider = new GoogleAuthProvider();
    try {
      await signInWithPopup(auth, provider);
      navigate('/profile');
    } catch (err: any) {
      console.error(err);
      if (err.code === 'auth/popup-closed-by-user') {
        setError('পপআপ বন্ধ করা হয়েছে। আবার চেষ্টা করুন।');
      } else {
        setError('গুগল লগইন করতে সমস্যা হয়েছে।');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-4 flex flex-col items-center justify-center min-h-[90vh] space-y-8 max-w-md mx-auto">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full"
      >
        <div className="flex flex-col items-center gap-4 mb-10">
          <div className="w-20 h-20 bg-primary rounded-3xl rotate-12 flex items-center justify-center shadow-xl shadow-primary/20">
            <span className="text-white text-4xl font-black -rotate-12">G</span>
          </div>
          <div className="text-center">
            <h1 className="text-3xl font-black text-primary">GlixBD</h1>
            <p className="text-sm text-text-muted font-medium">বাংলাদেশের সেরা ই-কমার্স প্ল্যাটফর্ম</p>
          </div>
        </div>

        <div className="w-full space-y-6 bg-white p-8 rounded-[40px] shadow-2xl shadow-gray-200/50 border border-gray-50">
          <div className="text-center space-y-2">
            <h2 className="text-2xl font-black text-text-main">স্বাগতম!</h2>
            <p className="text-sm text-text-muted">আপনার অ্যাকাউন্টে লগইন করুন কেনাকাটা শুরু করতে।</p>
          </div>

          {error && (
            <motion.div 
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              className="bg-red-50 text-red-500 p-4 rounded-2xl text-sm font-bold flex items-center gap-3 border border-red-100"
            >
              <AlertCircle size={18} />
              {error}
            </motion.div>
          )}

          <form onSubmit={handleEmailLogin} className="space-y-4">
            <div className="space-y-2">
              <label className="text-xs font-black text-text-muted uppercase tracking-widest pl-2">ইমেল এড্রেস</label>
              <div className="relative group">
                <Mail className="absolute left-6 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-primary transition-colors" size={20} />
                <input 
                  type="email" 
                  required
                  placeholder="example@mail.com"
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  className="w-full bg-gray-50 border border-transparent focus:border-primary focus:bg-white outline-none pl-14 pr-6 py-4 rounded-3xl font-bold transition-all"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-black text-text-muted uppercase tracking-widest pl-2">পাসওয়ার্ড</label>
              <div className="relative group">
                <Lock className="absolute left-6 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-primary transition-colors" size={20} />
                <input 
                  type={showPassword ? "text" : "password"}
                  required
                  placeholder="••••••••"
                  value={formData.password}
                  onChange={(e) => setFormData({...formData, password: e.target.value})}
                  className="w-full bg-gray-50 border border-transparent focus:border-primary focus:bg-white outline-none pl-14 pr-14 py-4 rounded-3xl font-bold transition-all"
                />
                <button 
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-6 top-1/2 -translate-y-1/2 text-gray-400 hover:text-text-main"
                >
                  {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                </button>
              </div>
            </div>

            <button 
              type="submit" 
              disabled={loading}
              className="w-full bg-primary text-white font-black py-4 rounded-3xl shadow-xl shadow-primary/30 flex items-center justify-center gap-2 active:scale-95 transition-all text-lg"
            >
              {loading ? (
                <div className="w-5 h-5 border-3 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  লগইন করুন
                  <LogIn size={20} />
                </>
              )}
            </button>
          </form>

          <div className="relative flex items-center justify-center">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-gray-100"></div>
            </div>
            <span className="relative px-4 bg-white text-[10px] text-text-muted font-extrabold uppercase tracking-[0.2em]">অথবা</span>
          </div>

          <button 
            onClick={handleGoogleLogin}
            className="w-full flex items-center justify-center gap-4 bg-white border border-gray-100 py-4 rounded-[24px] shadow-sm font-bold text-text-main active:scale-95 transition-transform hover:border-primary/50 transition-colors"
          >
            <img src="https://www.google.com/favicon.ico" className="w-5 h-5" alt="Google" />
            গুগল দিয়ে লগইন করুন
          </button>

          <p className="text-center text-sm font-bold text-text-muted">
            নতুন ইউজার?{' '}
            <NavLink to="/signup" className="text-primary hover:underline underline-offset-4">অ্যাকাউন্ট তৈরি করুন</NavLink>
          </p>
        </div>

        <p className="text-center text-[10px] text-text-muted px-6 leading-relaxed mt-8 font-medium">
          লগইন করার মাধ্যমে আপনি আমাদের <span className="text-primary font-bold">শর্তাবলি</span> এবং <span className="text-primary font-bold">গোপনীয়তা নীতির</span> সাথে একমত পোষণ করছেন।
        </p>
      </motion.div>
    </div>
  );
}
