import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Mail, Lock, User, ArrowRight, AlertCircle, Eye, EyeOff, Phone, Smartphone, CheckCircle2 } from 'lucide-react';
import { NavLink, useNavigate } from 'react-router-dom';
import { 
  createUserWithEmailAndPassword, 
  updateProfile, 
  signInWithPopup, 
  GoogleAuthProvider,
  RecaptchaVerifier,
  signInWithPhoneNumber,
  ConfirmationResult
} from 'firebase/auth';
import { auth } from '@/src/lib/firebase';
import { cn } from '@/src/lib/utils';

type SignupMethod = 'email' | 'phone';

export default function SignupScreen() {
  const navigate = useNavigate();
  const [method, setMethod] = useState<SignupMethod>('phone');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    phone: '+880'
  });
  const [otp, setOtp] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [verificationId, setVerificationId] = useState<ConfirmationResult | null>(null);
  const [step, setStep] = useState<'info' | 'otp'>('info');

  useEffect(() => {
    const initRecaptcha = () => {
      try {
        if (!window.recaptchaVerifier) {
          window.recaptchaVerifier = new RecaptchaVerifier(auth, 'recaptcha-container', {
            'size': 'invisible',
            'callback': () => {
              console.log('reCAPTCHA solved');
            },
            'expired-callback': () => {
              setError('reCAPTCHA এক্সপায়ার হয়েছে। আবার চেষ্টা করুন।');
            }
          });
        }
      } catch (err) {
        console.error('reCAPTCHA initialization failed:', err);
      }
    };

    initRecaptcha();

    return () => {
      if (window.recaptchaVerifier) {
        window.recaptchaVerifier.clear();
        window.recaptchaVerifier = null;
      }
    };
  }, []);

  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.phone.startsWith('+880') || formData.phone.length < 14) {
      setError('সঠিক বাংলাদেশি ফোন নাম্বার দিন (যেমন: +88017XXXXXXXX)');
      return;
    }
    
    setLoading(true);
    setError('');

    try {
      const confirmation = await signInWithPhoneNumber(auth, formData.phone, window.recaptchaVerifier);
      setVerificationId(confirmation);
      setStep('otp');
    } catch (err: any) {
      console.error(err);
      setError('ওটিপি পাঠাতে সমস্যা হয়েছে। আবার চেষ্টা করুন।');
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!verificationId) return;

    setLoading(true);
    setError('');

    try {
      const result = await verificationId.confirm(otp);
      if (result.user && formData.name) {
        await updateProfile(result.user, {
          displayName: formData.name
        });
      }
      navigate('/profile');
    } catch (err: any) {
      console.error(err);
      setError('ভুল ওটিপি কোড! আবার দেখুন।');
    } finally {
      setLoading(false);
    }
  };

  const handleEmailSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (formData.password !== formData.confirmPassword) {
      setError('পাসওয়ার্ড মিলছে না!');
      return;
    }

    setLoading(true);
    try {
      const userCredential = await createUserWithEmailAndPassword(
        auth, 
        formData.email, 
        formData.password
      );
      
      await updateProfile(userCredential.user, {
        displayName: formData.name
      });

      navigate('/profile');
    } catch (err: any) {
      console.error(err);
      if (err.code === 'auth/email-already-in-use') {
        setError('এই ইমেলটি ইতিমধ্যে ব্যবহার করা হয়েছে।');
      } else {
        setError('অ্যাকাউন্ট তৈরি করতে সমস্যা হয়েছে। আবার চেষ্টা করুন।');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    if (loading) return;
    setLoading(true);
    setError('');
    const provider = new GoogleAuthProvider();
    try {
      await signInWithPopup(auth, provider);
      navigate('/profile');
    } catch (err: any) {
      console.error(err);
      if (err.code === 'auth/popup-closed-by-user') {
        setError('পপআপ বন্ধ করা হয়েছে। আবার চেষ্টা করুন।');
      } else {
        setError('গুগল দিয়ে লগইন করতে সমস্যা হয়েছে।');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[90vh] flex items-center justify-center p-4">
      <div id="recaptcha-container"></div>
      
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md bg-white rounded-[40px] shadow-2xl shadow-gray-200/50 border border-gray-100 p-8 lg:p-12 mb-20"
      >
        <div className="text-center space-y-3 mb-10">
          <div className="w-16 h-16 bg-primary/10 text-primary rounded-2xl flex items-center justify-center mx-auto mb-6">
            <User size={32} strokeWidth={2.5} />
          </div>
          <h1 className="text-3xl font-black text-text-main">নতুন অ্যাকাউন্ট</h1>
          <p className="text-text-muted font-medium">আজই আমাদের সাথে যুক্ত হোন</p>
        </div>

        {/* Method Switcher */}
        <div className="flex bg-gray-50 p-1.5 rounded-2xl mb-8">
          <button 
            onClick={() => { setMethod('phone'); setStep('info'); }}
            className={cn(
              "flex-1 py-3 rounded-xl text-sm font-black transition-all flex items-center justify-center gap-2",
              method === 'phone' ? "bg-white text-primary shadow-sm" : "text-text-muted hover:text-text-main"
            )}
          >
            <Smartphone size={18} />
            মোবাইল
          </button>
          <button 
            onClick={() => setMethod('email')}
            className={cn(
              "flex-1 py-3 rounded-xl text-sm font-black transition-all flex items-center justify-center gap-2",
              method === 'email' ? "bg-white text-primary shadow-sm" : "text-text-muted hover:text-text-main"
            )}
          >
            <Mail size={18} />
            ইমেল
          </button>
        </div>

        {error && (
          <motion.div 
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-red-50 text-red-500 p-4 rounded-2xl text-sm font-bold flex items-center gap-3 mb-6 border border-red-100"
          >
            <AlertCircle size={18} />
            {error}
          </motion.div>
        )}

        <AnimatePresence mode="wait">
          {method === 'phone' ? (
            step === 'info' ? (
              <motion.form 
                key="phone-info"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                onSubmit={handleSendOtp} 
                className="space-y-5"
              >
                <div className="space-y-2">
                  <label className="text-xs font-black text-text-muted uppercase tracking-widest pl-2">আপনার নাম</label>
                  <div className="relative group">
                    <User className="absolute left-6 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-primary transition-colors" size={20} />
                    <input 
                      type="text" 
                      required
                      placeholder="আপনার নাম লিখুন..."
                      value={formData.name}
                      onChange={(e) => setFormData({...formData, name: e.target.value})}
                      className="w-full bg-gray-50 border border-transparent focus:border-primary focus:bg-white outline-none pl-14 pr-6 py-4 rounded-3xl font-bold transition-all"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-black text-text-muted uppercase tracking-widest pl-2">মোবাইল নাম্বার</label>
                  <div className="relative group">
                    <Phone className="absolute left-6 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-primary transition-colors" size={20} />
                    <input 
                      type="tel" 
                      required
                      placeholder="+8801700000000"
                      value={formData.phone}
                      onChange={(e) => setFormData({...formData, phone: e.target.value})}
                      className="w-full bg-gray-50 border border-transparent focus:border-primary focus:bg-white outline-none pl-14 pr-6 py-4 rounded-3xl font-bold transition-all"
                    />
                  </div>
                </div>

                <button 
                  type="submit" 
                  disabled={loading}
                  className="w-full bg-primary text-white font-black py-5 rounded-3xl shadow-2xl shadow-primary/30 flex items-center justify-center gap-3 active:scale-95 transition-all text-lg hover:shadow-primary/40 disabled:opacity-50"
                >
                  {loading ? (
                    <div className="w-6 h-6 border-4 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <>
                      ওটিপি পাঠান
                      <ArrowRight size={24} />
                    </>
                  )}
                </button>
              </motion.form>
            ) : (
              <motion.form 
                key="otp-verify"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                onSubmit={handleVerifyOtp} 
                className="space-y-5"
              >
                <div className="text-center space-y-2 mb-6">
                  <div className="w-12 h-12 bg-green-50 text-green-500 rounded-full flex items-center justify-center mx-auto">
                    <CheckCircle2 size={24} />
                  </div>
                  <p className="text-sm font-bold text-text-muted">
                    আমরা <span className="text-text-main">{formData.phone}</span> নাম্বারে একটি ওটিপি কোড পাঠিয়েছি।
                  </p>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-black text-text-muted uppercase tracking-widest pl-2 text-center block">ওটিপি কোড দিন</label>
                  <input 
                    type="text" 
                    required
                    maxLength={6}
                    placeholder="১ ২ ৩ ৪ ৫ ৬"
                    value={otp}
                    onChange={(e) => setOtp(e.target.value)}
                    className="w-full bg-gray-50 border-2 border-primary/10 focus:border-primary focus:bg-white outline-none px-6 py-5 rounded-3xl font-black text-center text-3xl tracking-[0.5em] transition-all"
                  />
                </div>

                <button 
                  type="submit" 
                  disabled={loading}
                  className="w-full bg-primary text-white font-black py-5 rounded-3xl shadow-2xl shadow-primary/30 flex items-center justify-center gap-3 active:scale-95 transition-all text-lg hover:shadow-primary/40 disabled:opacity-50"
                >
                  {loading ? (
                    <div className="w-6 h-6 border-4 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <>
                      ভেরিফাই করুন
                      <ArrowRight size={24} />
                    </>
                  )}
                </button>

                <button 
                  type="button" 
                  onClick={() => setStep('info')}
                  className="w-full text-sm font-bold text-primary hover:underline"
                >
                  নাম্বার পরিবর্তন করুন
                </button>
              </motion.form>
            )
          ) : (
            <motion.form 
              key="email-signup"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              onSubmit={handleEmailSignup} 
              className="space-y-5"
            >
              <div className="space-y-2">
                <label className="text-xs font-black text-text-muted uppercase tracking-widest pl-2">পূর্ণ নাম</label>
                <div className="relative group">
                  <User className="absolute left-6 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-primary transition-colors" size={20} />
                  <input 
                    type="text" 
                    required
                    placeholder="আপনার নাম লিখুন..."
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    className="w-full bg-gray-50 border border-transparent focus:border-primary focus:bg-white outline-none pl-14 pr-6 py-4 rounded-3xl font-bold transition-all"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-black text-text-muted uppercase tracking-widest pl-2">ইমেল এড্রেস</label>
                <div className="relative group">
                  <Mail className="absolute left-6 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-primary transition-colors" size={20} />
                  <input 
                    type="email" 
                    required
                    placeholder="example@mail.com"
                    value={formData.email}
                    onChange={(e) => setFormData({...formData, email: e.target.value})}
                    className="w-full bg-gray-50 border border-transparent focus:border-primary focus:bg-white outline-none pl-14 pr-6 py-4 rounded-3xl font-bold transition-all"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-black text-text-muted uppercase tracking-widest pl-2">পাসওয়ার্ড</label>
                <div className="relative group">
                  <Lock className="absolute left-6 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-primary transition-colors" size={20} />
                  <input 
                    type={showPassword ? "text" : "password"}
                    required
                    placeholder="••••••••"
                    value={formData.password}
                    onChange={(e) => setFormData({...formData, password: e.target.value})}
                    className="w-full bg-gray-50 border border-transparent focus:border-primary focus:bg-white outline-none pl-14 pr-14 py-4 rounded-3xl font-bold transition-all"
                  />
                  <button 
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-6 top-1/2 -translate-y-1/2 text-gray-400 hover:text-text-main"
                  >
                    {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                  </button>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-black text-text-muted uppercase tracking-widest pl-2">পাসওয়ার্ড নিশ্চিত করুন</label>
                <div className="relative group">
                  <Lock className="absolute left-6 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-primary transition-colors" size={20} />
                  <input 
                    type={showPassword ? "text" : "password"}
                    required
                    placeholder="••••••••"
                    value={formData.confirmPassword}
                    onChange={(e) => setFormData({...formData, confirmPassword: e.target.value})}
                    className="w-full bg-gray-50 border border-transparent focus:border-primary focus:bg-white outline-none pl-14 pr-6 py-4 rounded-3xl font-bold transition-all"
                  />
                </div>
              </div>

              <button 
                type="submit" 
                disabled={loading}
                className="w-full bg-primary text-white font-black py-5 rounded-3xl shadow-2xl shadow-primary/30 flex items-center justify-center gap-3 active:scale-95 transition-all text-lg hover:shadow-primary/40 disabled:opacity-50"
              >
                {loading ? (
                  <div className="w-6 h-6 border-4 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <>
                    অ্যাকাউন্ট তৈরি করুন
                    <ArrowRight size={24} />
                  </>
                )}
              </button>
            </motion.form>
          )}
        </AnimatePresence>

        <div className="mt-8 space-y-6">
          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-gray-100"></div>
            </div>
            <div className="relative flex justify-center text-xs font-black uppercase tracking-widest">
              <span className="bg-white px-4 text-text-muted">অথবা</span>
            </div>
          </div>

          <button 
            onClick={handleGoogleSignIn}
            className="w-full flex items-center justify-center gap-4 bg-white border border-gray-200 py-4 rounded-2xl shadow-sm font-bold text-text-main active:scale-95 transition-transform hover:border-primary/50 transition-colors"
          >
            <img src="https://www.google.com/favicon.ico" className="w-5 h-5" alt="Google" />
            গুগল দিয়ে সাইনআপ করুন
          </button>

          <p className="text-center text-sm font-bold text-text-muted">
            ইতিমধ্যে অ্যাকাউন্ট আছে?{' '}
            <NavLink to="/login" className="text-primary hover:underline underline-offset-4">লগইন করুন</NavLink>
          </p>
        </div>
      </motion.div>
    </div>
  );
}

declare global {
  interface Window {
    recaptchaVerifier: any;
  }
}
