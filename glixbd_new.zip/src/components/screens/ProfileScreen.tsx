import React, { useState, useEffect } from 'react';
import { auth, db } from '@/src/lib/firebase';
import { onAuthStateChanged, signOut, GoogleAuthProvider, signInWithPopup } from 'firebase/auth';
import { collection, query, where, getDocs, orderBy, limit } from 'firebase/firestore';
import { Order, OrderStatusLabels } from '@/src/types';
import { formatDate, formatPrice, cn } from '@/src/lib/utils';
import { User, Package, MapPin, Wallet, Bell, LogOut, ChevronRight, ShoppingBag, Heart, LogIn, ShieldCheck } from 'lucide-react';
import { useNavigate, NavLink, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useAdmin } from '@/src/hooks/useAdmin';

export default function ProfileScreen() {
  const [user, setUser] = useState(auth.currentUser);
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const { isAdmin } = useAdmin();
  const navigate = useNavigate();
  const [isPromoting, setIsPromoting] = useState(false);

  const handleClaimAdmin = async () => {
    if (!user) return;
    setIsPromoting(true);
    try {
      const { setDoc, doc, serverTimestamp } = await import('firebase/firestore');
      await setDoc(doc(db, 'admins', user.uid), {
        email: user.email,
        role: 'super_admin',
        createdAt: serverTimestamp()
      });
      window.location.reload();
    } catch (err) {
      console.error(err);
      alert('অ্যাডমিন হতে সমস্যা হয়েছে। আপনার ইমেল কি oksumondey153@gmail.com?');
    } finally {
      setIsPromoting(false);
    }
  };

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (u) => {
      setUser(u);
      if (u) {
        const q = query(
          collection(db, 'orders'), 
          where('userId', '==', u.uid), 
          orderBy('createdAt', 'desc'),
          limit(5)
        );
        const snap = await getDocs(q);
        setOrders(snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Order)));
      }
      setLoading(false);
    });
    return unsub;
  }, []);

  const handleLogout = async () => {
    await signOut(auth);
    navigate('/');
  };

  const handleGoogleLogin = async () => {
    const provider = new GoogleAuthProvider();
    try {
      await signInWithPopup(auth, provider);
    } catch (error) {
      console.error(error);
    }
  };

  if (loading) return <div className="p-8 text-center">লোড হচ্ছে...</div>;

  if (!user) {
    return (
      <div className="p-4 flex flex-col items-center justify-center min-h-[80vh] space-y-8 max-w-sm mx-auto">
        <div className="w-24 h-24 bg-primary/10 text-primary rounded-[32px] rotate-12 flex items-center justify-center shadow-xl shadow-primary/5">
          <User size={48} className="-rotate-12" />
        </div>
        <div className="text-center space-y-3">
          <h2 className="text-2xl font-black text-text-main">হ্যালো, স্বাগতম!</h2>
          <p className="text-sm text-text-muted font-medium px-4">আপনার অর্ডার ট্র্যাক করতে এবং পছন্দের পণ্যগুলো দেখতে লগইন করুন।</p>
        </div>

        <div className="w-full space-y-4">
          <NavLink 
            to="/login"
            className="w-full flex items-center justify-center gap-3 bg-primary text-white py-4 rounded-2xl shadow-xl shadow-primary/20 font-bold active:scale-95 transition-all"
          >
            <LogIn size={20} />
            ইমেল দিয়ে লগইন করুন
          </NavLink>

          <NavLink 
            to="/signup"
            className="w-full flex items-center justify-center gap-3 bg-white border-2 border-primary/20 text-primary py-4 rounded-2xl font-bold active:scale-95 transition-all"
          >
            <User size={20} />
            নতুন অ্যাকাউন্ট খুলুন
          </NavLink>

          <div className="relative flex items-center justify-center py-2">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-gray-100"></div>
            </div>
            <span className="relative px-3 bg-white text-[10px] text-text-muted font-black uppercase tracking-widest">অথবা</span>
          </div>

          <button 
            onClick={handleGoogleLogin}
            className="w-full flex items-center justify-center gap-4 bg-white border border-gray-200 py-4 rounded-2xl shadow-sm font-bold text-text-main active:scale-95 transition-all hover:bg-gray-50"
          >
            <img src="https://www.google.com/favicon.ico" className="w-5 h-5" alt="Google" />
            গুগল দিয়ে লগইন করুন
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 p-4">
      {/* Header */}
      <div className="flex items-center gap-4 bg-white p-6 rounded-3xl border border-gray-100 shadow-sm">
        <div className="w-20 h-20 rounded-full border-4 border-primary/20 overflow-hidden shadow-Inner">
          <img src={user.photoURL || `https://ui-avatars.com/api/?name=${user.displayName}`} alt={user.displayName || 'User'} className="w-full h-full object-cover" />
        </div>
        <div className="flex-1 space-y-1">
          <h2 className="text-xl font-bold line-clamp-1">{user.displayName}</h2>
          <p className="text-xs text-text-muted">{user.email}</p>
          <div className="flex items-center gap-1.5 bg-green-50 text-green-600 px-2 py-0.5 rounded-full text-[10px] font-bold w-fit">
            <User size={10} />
            <span>ভেরিফাইড ইউজার</span>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        <StatCard label="মোট অর্ডার" value={orders.length} color="bg-blue-50 text-blue-600" />
        <StatCard label="ওয়ালট" value="৳০" color="bg-orange-50 text-orange-600" />
        <StatCard label="পয়েন্টস" value="৫০" color="bg-purple-50 text-purple-600" />
      </div>

      {/* Admin Panel Link */}
      {isAdmin && (
        <NavLink 
          to="/admin" 
          className="bg-primary/10 p-4 rounded-3xl border border-primary/20 flex items-center justify-between group active:scale-95 transition-all"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary text-white rounded-xl flex items-center justify-center">
              <ShieldCheck size={20} />
            </div>
            <div>
              <h4 className="text-sm font-black text-primary">অ্যাডমিন ড্যাশবোর্ড</h4>
              <p className="text-[10px] font-bold text-primary/60 uppercase tracking-widest">সাইট কন্ট্রোল প্যানেল</p>
            </div>
          </div>
          <ChevronRight size={20} className="text-primary" />
        </NavLink>
      )}

      {/* Developer Admin Claim Button */}
      {!isAdmin && user?.email === 'oksumondey153@gmail.com' && (
        <button 
          onClick={handleClaimAdmin}
          disabled={isPromoting}
          className="w-full bg-orange-500 text-white font-black py-4 rounded-3xl shadow-xl shadow-orange-200 active:scale-95 transition-all disabled:opacity-50"
        >
          {isPromoting ? 'প্রসেসিং...' : 'নিজেকে অ্যাডমিন হিসেবে সেট করুন'}
        </button>
      )}

      {/* Recent Orders */}
      <div className="space-y-4">
        <div className="flex items-center justify-between px-1">
          <h3 className="font-bold text-sm">সাম্প্রতিক অর্ডার</h3>
          <button className="text-primary text-xs font-bold">সব দেখুন</button>
        </div>
        {orders.length > 0 ? (
          <div className="space-y-3">
            {orders.map(order => (
              <NavLink 
                to={`/tracking/${order.orderNumber}`} 
                key={order.id} 
                className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-gray-50 rounded-lg flex items-center justify-center text-primary">
                    <Package size={20} />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold">#{order.orderNumber}</h4>
                    <p className="text-[10px] text-text-muted">{formatDate(order.createdAt)}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-xs font-black text-primary">{formatPrice(order.total)}</p>
                  <p className="text-[10px] text-orange-500 font-bold">{OrderStatusLabels[order.status]}</p>
                </div>
              </NavLink>
            ))}
          </div>
        ) : (
          <div className="bg-white p-8 rounded-3xl border border-gray-100 text-center space-y-2">
            <p className="text-xs text-text-muted">আপনি এখনো কোনো অর্ডার করেননি।</p>
            <NavLink to="/" className="text-primary text-xs font-bold underline">নতুন পণ্য খুঁজুন</NavLink>
          </div>
        )}
      </div>

      {/* Menu */}
      <div className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden">
        <MenuItem icon={<MapPin size={20} />} label="ডেলিভারি ঠিকানা" to="/profile" />
        <MenuItem icon={<Heart size={20} />} label="পছন্দের তালিকা" to="/wishlist" />
        <MenuItem icon={<Bell size={20} />} label="নোটিফিকেশন" to="/notifications" />
        <MenuItem icon={<Wallet size={20} />} label="পেমেন্ট মেথড" to="/profile" />
        <button 
          onClick={handleLogout}
          className="w-full flex items-center gap-4 px-6 py-4 text-red-500 hover:bg-red-50 transition-colors border-t border-gray-50"
        >
          <LogOut size={20} />
          <span className="text-sm font-bold">লগআউট করুন</span>
        </button>
      </div>
    </div>
  );
}

function StatCard({ label, value, color }: { label: string, value: string | number, color: string }) {
  return (
    <div className={cn("flex flex-col items-center justify-center p-4 rounded-2xl border border-gray-100 shadow-sm bg-white gap-1")}>
      <span className="text-lg font-black text-text-main">{value}</span>
      <span className="text-[9px] font-bold text-text-muted uppercase text-center">{label}</span>
    </div>
  );
}

function MenuItem({ icon, label, to }: { icon: React.ReactNode, label: string, to?: string }) {
  const Component = to ? Link : 'button';
  return (
    <Component 
      to={to || '#'} 
      className="w-full flex items-center gap-4 px-6 py-4 hover:bg-gray-50 transition-colors border-b border-gray-50 last:border-0 group"
    >
      <div className="text-text-muted group-hover:text-primary transition-colors">
        {icon}
      </div>
      <span className="flex-1 text-sm font-bold text-left">{label}</span>
      <ChevronRight size={18} className="text-gray-300" />
    </Component>
  );
}
