import React, { useState, useEffect } from 'react';
import { collection, query, where, getDocs, limit } from 'firebase/firestore';
import { db } from '@/src/lib/firebase';
import { Product } from '@/src/types';
import { Search, Filter, SlidersHorizontal, ShoppingCart, Star, History, TrendingUp, X } from 'lucide-react';
import { NavLink } from 'react-router-dom';
import { formatPrice, cn } from '@/src/lib/utils';
import { motion, AnimatePresence } from 'framer-motion';

export default function SearchScreen() {
  const [searchTerm, setSearchTerm] = useState('');
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(false);
  const [recentSearches, setRecentSearches] = useState(['পাঞ্জাবী', 'ইয়ারবাডস', 'মধু']);

  const performSearch = async (term: string) => {
    if (!term.trim()) {
      setProducts([]);
      return;
    }
    setLoading(true);
    try {
      const q = query(
        collection(db, 'products'),
        where('nameBn', '>=', term),
        where('nameBn', '<=', term + '\uf8ff'),
        limit(20)
      );
      const snap = await getDocs(q);
      setProducts(snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Product)));
      
      // Update recent searches if term is not already there
      if (term.trim() && !recentSearches.includes(term.trim())) {
        setRecentSearches(prev => [term.trim(), ...prev.slice(0, 4)]);
      }
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const timer = setTimeout(() => {
      performSearch(searchTerm);
    }, 500);
    return () => clearTimeout(timer);
  }, [searchTerm]);

  return (
    <div className="max-w-7xl mx-auto p-4 lg:p-0 space-y-10 pb-20">
      {/* Premium Search Header */}
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <h2 className="text-3xl lg:text-5xl font-black text-text-main tracking-tight flex items-center gap-3">
             <div className="w-3 h-10 lg:w-4 lg:h-14 bg-primary rounded-full"></div>
             খুঁজুন
          </h2>
          {searchTerm && (
            <p className="text-sm font-bold text-text-muted">
              সার্চ রেজাল্ট: <span className="text-primary">"{searchTerm}"</span> ({products.length} টি পণ্য)
            </p>
          )}
        </div>

        <div className="flex gap-3">
          <div className="flex-1 bg-white border border-gray-100 rounded-[30px] flex items-center px-6 shadow-xl shadow-gray-100/50 focus-within:border-primary focus-within:shadow-primary/5 transition-all duration-300">
            <Search className="text-text-muted" size={24} />
            <input 
              type="text" 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="আপনার পছন্দের পোশাক বা গিজমো খুঁজুন..." 
              className="flex-1 py-5 px-3 outline-none bg-transparent text-sm lg:text-lg font-medium"
            />
            {searchTerm && (
              <button onClick={() => setSearchTerm('')} className="p-2 hover:bg-gray-50 rounded-full text-text-muted transition-colors">
                <X size={20} />
              </button>
            )}
          </div>
          <button className="bg-primary text-white p-5 rounded-[30px] shadow-xl shadow-primary/20 active:scale-95 transition-all hover:bg-primary/90">
            <SlidersHorizontal size={28} />
          </button>
        </div>
      </div>

      {loading ? (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
          {[1,2,3,4,5,6,7,8].map(i => (
            <div key={i} className="aspect-[4/5] bg-gray-50 animate-pulse rounded-[40px] border border-gray-50" />
          ))}
        </div>
      ) : products.length > 0 ? (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 lg:gap-10">
          <AnimatePresence mode="popLayout">
            {products.map((p) => (
              <motion.div 
                key={p.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.3 }}
              >
                <SearchProductCard product={p} />
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      ) : searchTerm ? (
        <div className="py-24 text-center space-y-6 max-w-sm mx-auto">
          <div className="w-24 h-24 bg-gray-50 rounded-[40px] flex items-center justify-center mx-auto text-gray-200">
             <Search size={48} />
          </div>
          <div className="space-y-2">
            <h3 className="text-xl font-bold">দুঃখিত, কোনো পণ্য পাওয়া যায়নি।</h3>
            <p className="text-sm text-text-muted font-medium">অন্য কোনো নাম দিয়ে চেষ্টা করুন অথবা ক্যাটাগরি ব্রাউজ করুন।</p>
          </div>
          <button onClick={() => setSearchTerm('')} className="bg-primary text-white font-black px-10 py-4 rounded-3xl shadow-xl shadow-primary/20 active:scale-95 transition-all">আবার সার্চ করুন</button>
        </div>
      ) : (
        <div className="space-y-12">
          {/* Recent Searches */}
          {recentSearches.length > 0 && (
            <div className="space-y-4">
               <h3 className="font-black text-sm lg:text-base text-text-muted flex items-center gap-2 uppercase tracking-widest">
                 <History size={16} />
                 আগের সার্চগুলো
               </h3>
               <div className="flex flex-wrap gap-3">
                 {recentSearches.map(tag => (
                   <button 
                     key={tag}
                     onClick={() => setSearchTerm(tag)} 
                     className="bg-white border border-gray-100 px-6 py-3 rounded-2xl text-sm font-bold text-text-main shadow-sm hover:border-primary hover:text-primary hover:shadow-lg transition-all"
                   >
                     {tag}
                   </button>
                 ))}
               </div>
            </div>
          )}

          {/* Trending Categories mockup */}
          <div className="space-y-6">
            <h3 className="font-black text-sm lg:text-base text-text-muted flex items-center gap-2 uppercase tracking-widest">
              <TrendingUp size={16} />
              জনপ্রিয় ক্যাটাগরি
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
              {['হোম ডেকোর', 'স্মার্টফোন', 'লেদার ব্যাগ', 'স্নিকার্স', 'বিউটি পণ্য'].map(cat => (
                 <button 
                  key={cat}
                  className="bg-gray-50/80 backdrop-blur border border-gray-100 p-8 rounded-[40px] text-center hover:bg-white hover:shadow-xl hover:border-primary/20 transition-all font-black text-text-main"
                 >
                    {cat}
                 </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function SearchProductCard({ product }: { product: Product }) {
  const discount = product.salePrice ? Math.round(((product.price - product.salePrice) / product.price) * 100) : 0;

  return (
    <NavLink to={`/product/${product.id}`} className="group space-y-4">
      <div className="relative aspect-square bg-gray-50 rounded-[40px] overflow-hidden border border-gray-50 group-hover:shadow-2xl group-hover:shadow-primary/10 transition-all duration-500">
        <img src={product.images[0]} alt={product.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
        {discount > 0 && (
          <div className="absolute top-4 left-4 bg-primary text-white text-[10px] font-black px-3 py-1.5 rounded-2xl shadow-xl shadow-primary/30">
            {discount}% ছাড়
          </div>
        )}
        <button className="absolute bottom-4 right-4 w-12 h-12 bg-white/90 backdrop-blur shadow-2xl rounded-2xl flex items-center justify-center text-primary transform translate-y-16 group-hover:translate-y-0 transition-all duration-500 hover:bg-primary hover:text-white">
           <ShoppingCart size={22} />
        </button>
      </div>
      <div className="px-2 space-y-2">
        <div className="flex items-center gap-1.5">
           <div className="flex text-yellow-400">
             {[1,2,3,4,5].map(i => <Star key={i} size={10} fill={i <= Math.round(product.rating) ? "currentColor" : "none"} className={i <= Math.round(product.rating) ? "" : "text-gray-200"} />)}
           </div>
           <span className="text-[10px] font-black text-text-muted">({product.rating})</span>
        </div>
        <h4 className="font-black text-text-main line-clamp-2 leading-tight lg:text-lg group-hover:text-primary transition-colors">{product.nameBn}</h4>
        <div className="flex items-end gap-2">
          <span className="text-primary font-black lg:text-2xl">{formatPrice(product.salePrice || product.price)}</span>
          {product.salePrice && (
            <span className="text-xs text-text-muted line-through font-bold mb-0.5">{formatPrice(product.price)}</span>
          )}
        </div>
      </div>
    </NavLink>
  );
}
