import React from 'react';
import { Heart, ShoppingCart } from 'lucide-react';
import { NavLink } from 'react-router-dom';

export default function WishlistScreen() {
  return (
    <div className="p-4 space-y-6">
      <h2 className="text-xl font-bold border-l-4 border-primary pl-3">পছন্দের তালিকা</h2>
      
      <div className="flex flex-col items-center justify-center py-20 text-center space-y-4">
        <div className="w-20 h-20 bg-primary/5 text-primary rounded-full flex items-center justify-center">
          <Heart size={40} fill="currentColor" />
        </div>
        <div className="space-y-1">
          <h3 className="font-bold text-lg">আপনার তালিকা খালি</h3>
          <p className="text-sm text-text-muted px-10">আপনার পছন্দের পণ্যগুলো এখানে জমা করে রাখতে পারেন।</p>
        </div>
        <NavLink to="/" className="bg-primary text-white px-8 py-3 rounded-2xl font-bold shadow-lg active:scale-95 transition-transform">
          পণ্য পছন্দ করুন
        </NavLink>
      </div>
    </div>
  );
}
