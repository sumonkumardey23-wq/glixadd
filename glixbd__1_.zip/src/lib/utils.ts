import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function getBangladeshDateTime() {
  const now = new Date();
  
  const timeOptions: Intl.DateTimeFormatOptions = {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true,
    timeZone: 'Asia/Dhaka'
  };

  const dateOptions: Intl.DateTimeFormatOptions = {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    weekday: 'long',
    timeZone: 'Asia/Dhaka'
  };

  const banglaDate = new Intl.DateTimeFormat('bn-BD', dateOptions).format(now);
  const englishDate = new Intl.DateTimeFormat('en-US', dateOptions).format(now);
  const time = new Intl.DateTimeFormat('en-US', timeOptions).format(now);

  return {
    bangla: banglaDate,
    english: englishDate,
    time: time
  };
}

export function formatPrice(price: number) {
  return `৳${price.toLocaleString('bn-BD')}`;
}

export function formatDate(date: any) {
  if (!date) return '';
  const d = date.toDate ? date.toDate() : new Date(date);
  return d.toLocaleDateString('bn-BD', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });
}
