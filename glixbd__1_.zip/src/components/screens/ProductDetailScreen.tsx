import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { doc, getDoc, updateDoc, increment } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '@/src/lib/firebase';
import { Product } from '@/src/types';
import { formatPrice, cn } from '@/src/lib/utils';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ShoppingCart, Star, ShieldCheck, Truck, RotateCcw, Minus, Plus, Heart, Share2, Package } from 'lucide-react';
import { useCart } from '@/src/lib/CartContext';

export default function ProductDetailScreen() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [qty, setQty] = useState(1);
  const [activeImage, setActiveImage] = useState(0);

  useEffect(() => {
    async function fetchProduct() {
      if (!id) return;
      try {
        const productRef = doc(db, 'products', id);
        const snap = await getDoc(productRef);
        if (snap.exists()) {
          setProduct({ id: snap.id, ...snap.data() } as Product);
          // Increment view count
          await updateDoc(productRef, {
            views: increment(1)
          });
        }
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, `products/${id}`);
      } finally {
        setLoading(false);
      }
    }
    fetchProduct();
  }, [id]);

  if (loading) return (
    <div className="flex flex-col items-center justify-center min-h-[60vh] gap-4">
      <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
      <p className="font-bold text-text-muted">লোড হচ্ছে...</p>
    </div>
  );

  if (!product) return (
    <div className="p-12 text-center space-y-4">
      <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto text-red-400">
        <ShoppingCart size={40} />
      </div>
      <h2 className="text-xl font-bold">পণ্যটি পাওয়া যায়নি।</h2>
      <button onClick={() => navigate('/')} className="text-primary font-bold underline">হোমে ফিরে যান</button>
    </div>
  );

  const discount = product.salePrice ? Math.round(((product.price - product.salePrice) / product.price) * 100) : 0;

  const handleAddToCart = () => {
    addToCart({
      productId: product.id,
      name: product.nameBn,
      price: product.salePrice || product.price,
      quantity: qty,
      image: product.images[0]
    });
  };

  const handleBuyNow = () => {
    addToCart({
      productId: product.id,
      name: product.nameBn,
      price: product.salePrice || product.price,
      quantity: qty,
      image: product.images[0]
    });
    navigate('/cart');
  };

  return (
    <div className="pb-24 lg:grid lg:grid-cols-2 lg:gap-12 items-start max-w-7xl mx-auto">
      {/* Mobile Back Button */}
      <div className="lg:hidden fixed top-4 left-4 z-50">
        <button onClick={() => navigate(-1)} className="p-3 bg-white/90 backdrop-blur-lg rounded-2xl shadow-xl text-primary active:scale-90 transition-transform">
          <ChevronLeft size={24} />
        </button>
      </div>

      {/* Image Gallery */}
      <div className="space-y-6 lg:sticky lg:top-24">
        <div className="relative aspect-square bg-gray-50 lg:rounded-[40px] overflow-hidden group">
          <AnimatePresence mode="wait">
            <motion.img 
              key={activeImage}
              initial={{ opacity: 0, scale: 1.1 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ duration: 0.4 }}
              src={product.images[activeImage]} 
              alt={product.name} 
              className="w-full h-full object-cover"
            />
          </AnimatePresence>
          
          <div className="absolute bottom-6 left-0 right-0 flex justify-center gap-2 px-4">
            {product.images.map((_, idx) => (
              <button 
                key={idx}
                onClick={() => setActiveImage(idx)}
                className={cn(
                  "h-1.5 rounded-full transition-all duration-300",
                  idx === activeImage ? "bg-primary w-8" : "bg-white/40 w-2 hover:bg-white/60"
                )}
              />
            ))}
          </div>

          <button className="absolute top-6 right-6 p-3 bg-white/90 backdrop-blur shadow-xl rounded-2xl text-text-muted hover:text-red-500 transition-colors">
            <Heart size={20} />
          </button>
        </div>

        {product.images.length > 1 && (
          <div className="flex gap-4 px-4 lg:px-0 overflow-x-auto no-scrollbar">
            {product.images.map((img, idx) => (
              <button 
                key={idx}
                onClick={() => setActiveImage(idx)}
                className={cn(
                  "w-20 h-20 lg:w-24 lg:h-24 rounded-3xl overflow-hidden border-2 transition-all p-1 bg-white shrink-0",
                  idx === activeImage ? "border-primary shadow-xl shadow-primary/10" : "border-transparent opacity-60 grayscale hover:grayscale-0 hover:opacity-100"
                )}
              >
                <img src={img} className="w-full h-full object-cover rounded-2xl" alt="" />
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Product Info */}
      <div className="p-6 lg:p-0 space-y-10 lg:mt-6">
        <div className="space-y-4">
          <div className="flex flex-wrap items-center gap-3">
            <span className="bg-primary/10 text-primary text-[10px] lg:text-xs font-black uppercase px-4 py-1.5 rounded-full tracking-widest">
              প্রিমিয়াম কালেকশন
            </span>
            <div className="flex items-center gap-1.5 text-yellow-400 bg-yellow-400/10 px-3 py-1 rounded-full">
              <Star size={14} fill="currentColor" />
              <span className="text-xs font-black text-yellow-700">{product.rating}</span>
            </div>
            <span className="text-xs text-text-muted font-bold">({product.reviewCount} রিভিউজ)</span>
          </div>
          
          <h1 className="text-3xl lg:text-5xl font-black text-text-main leading-tight tracking-tight">{product.nameBn}</h1>
          
          <div className="flex items-end gap-4">
            <div className="space-y-1">
              <p className="text-[10px] text-text-muted font-black uppercase tracking-widest leading-none">বর্তমান দাম</p>
              <span className="text-4xl font-black text-primary tracking-tighter">{formatPrice(product.salePrice || product.price)}</span>
            </div>
            {product.salePrice && (
              <div className="flex flex-col mb-1 gap-2">
                <span className="text-lg text-text-muted line-through font-bold">{formatPrice(product.price)}</span>
                <span className="bg-red-500 text-white text-[10px] font-black px-3 py-1 rounded-xl shadow-lg shadow-red-500/20 w-fit">
                  {Math.round(((product.price - product.salePrice) / product.price) * 100)}% ছাড়
                </span>
              </div>
            )}
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-black text-sm lg:text-base flex items-center gap-2">
              <span className="w-1 h-5 bg-primary rounded-full"></span>
              পণ্যের বিবরণ
            </h3>
            <button className="text-primary p-2 hover:bg-primary/10 rounded-xl transition-colors">
              <Share2 size={18} />
            </button>
          </div>
          <p className="text-sm lg:text-lg text-text-muted leading-relaxed font-medium bg-gray-50 p-6 rounded-[32px] border border-gray-100">
            {product.descriptionBn || product.description}
          </p>
        </div>

        {/* Benefits Section */}
        <div className="grid grid-cols-2 gap-4">
          <FeatureCard icon={<ShieldCheck size={24} className="text-blue-500" />} title="১০০% অথেনটিক" subtitle="সরাসরি আমদানিকৃত" />
          <FeatureCard icon={<Truck size={24} className="text-green-500" />} title="বিদ্যুৎ গতিতে" subtitle="২৪-৪৮ ঘন্টায় পৌঁছে যাবে" />
          <FeatureCard icon={<RotateCcw size={24} className="text-orange-500" />} title="৭ দিনের রিটার্ন" subtitle="সহজ শর্তে ফেরতযোগ্য" />
          <FeatureCard icon={<Package size={24} className="text-purple-500" />} title="নিরাপদ প্যাকিং" subtitle="পণ্য সুরক্ষায় নিশ্চিন্ত" />
        </div>

        {/* Sticky/Fixed Checkout Bar for Mobile - and Sidebar for Desktop */}
        <div className="fixed lg:relative bottom-0 left-0 right-0 bg-white/90 lg:bg-transparent backdrop-blur-xl lg:backdrop-blur-none border-t lg:border-none border-gray-100 p-4 lg:p-0 z-50 flex flex-col gap-3 lg:pt-6">
          <div className="flex gap-3">
            <div className="flex items-center bg-gray-100 lg:bg-white lg:border lg:border-gray-100 rounded-3xl px-2 py-1 shadow-sm w-32 lg:w-40 shrink-0">
              <button 
                onClick={() => setQty(q => Math.max(1, q-1))}
                className="w-10 h-10 flex items-center justify-center bg-white border border-gray-200 lg:border-none rounded-2xl hover:text-primary transition-colors shadow-sm"
              >
                <Minus size={18} />
              </button>
              <span className="flex-1 text-center font-black text-lg">{qty}</span>
              <button 
                onClick={() => setQty(q => q+1)}
                className="w-10 h-10 flex items-center justify-center bg-white border border-gray-200 lg:border-none rounded-2xl hover:text-primary transition-colors shadow-sm"
              >
                <Plus size={18} />
              </button>
            </div>
            
            <button 
              onClick={handleAddToCart}
              className="flex-1 bg-primary/10 text-primary font-black py-4 rounded-3xl flex items-center justify-center gap-2 hover:bg-primary hover:text-white active:scale-95 transition-all text-sm lg:text-base border border-primary/20"
            >
              <ShoppingCart size={20} />
              কার্টে যোগ
            </button>
          </div>
          
          <button 
            onClick={handleBuyNow}
            className="w-full bg-primary text-white font-black py-4 lg:py-5 rounded-3xl shadow-2xl shadow-primary/30 flex items-center justify-center active:scale-95 transition-all text-lg hover:bg-primary/90"
          >
            এখনই কিনুন
          </button>
        </div>
      </div>
    </div>
  );
}

function FeatureCard({ icon, title, subtitle }: { icon: React.ReactNode, title: string, subtitle: string }) {
  return (
    <div className="bg-white p-5 rounded-[32px] border border-gray-100 shadow-sm flex flex-col gap-3 group hover:border-primary/20 hover:shadow-lg transition-all">
      <div className="w-12 h-12 bg-gray-50 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform">
        {icon}
      </div>
      <div>
        <h4 className="text-sm font-black text-text-main">{title}</h4>
        <p className="text-[10px] text-text-muted font-bold mt-0.5">{subtitle}</p>
      </div>
    </div>
  );
}
