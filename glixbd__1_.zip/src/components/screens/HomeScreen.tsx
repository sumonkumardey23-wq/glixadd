import React, { useEffect, useState } from 'react';
import { collection, getDocs, limit, query, where, orderBy } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '@/src/lib/firebase';
import { Product, Category } from '@/src/types';
import { motion } from 'framer-motion';
import { ChevronRight, ShoppingCart, Star, Timer } from 'lucide-react';
import { formatPrice, cn } from '@/src/lib/utils';
import { NavLink } from 'react-router-dom';

export default function HomeScreen() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [featuredProducts, setFeaturedProducts] = useState<Product[]>([]);
  const [popularProducts, setPopularProducts] = useState<Product[]>([]);
  const [flashSaleProducts, setFlashSaleProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchData() {
      try {
        const catSnap = await getDocs(collection(db, 'categories'));
        setCategories(catSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Category)));

        const featuredQuery = query(collection(db, 'products'), where('isFeatured', '==', true), limit(6));
        const featuredSnap = await getDocs(featuredQuery);
        setFeaturedProducts(featuredSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Product)));

        const popularQuery = query(collection(db, 'products'), orderBy('views', 'desc'), limit(6));
        const popularSnap = await getDocs(popularQuery);
        setPopularProducts(popularSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Product)));

        const flashQuery = query(collection(db, 'products'), where('isFlashSale', '==', true), limit(4));
        const flashSnap = await getDocs(flashQuery);
        setFlashSaleProducts(flashSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Product)));
      } catch (error) {
        handleFirestoreError(error, OperationType.LIST, 'home_data');
      } finally {
        setLoading(false);
      }
    }
    fetchData();
  }, []);

  if (loading) return (
    <div className="p-4 space-y-4">
      <div className="h-40 bg-gray-200 animate-pulse rounded-xl" />
      <div className="grid grid-cols-4 gap-4">
        {[1,2,3,4].map(i => <div key={i} className="h-20 bg-gray-200 animate-pulse rounded-lg" />)}
      </div>
    </div>
  );

  return (
    <div className="space-y-6 pb-4">
      {/* Banner */}
      <section className="px-4 pt-4 lg:px-0">
        <div className="relative h-48 lg:h-64 rounded-3xl overflow-hidden bg-primary p-8 lg:p-12 flex items-center shadow-xl shadow-primary/20">
          <div className="z-10 max-w-md space-y-4">
            <motion.div 
              initial={{ x: -20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              className="bg-white text-primary text-[10px] lg:text-xs font-black px-4 py-1.5 rounded-full w-fit uppercase tracking-wider"
            >
              ৫০% পর্যন্ত বিশাল ছাড়
            </motion.div>
            <h2 className="text-3xl lg:text-5xl font-black text-white leading-none">শীতকালীন ধামাকা সেল!</h2>
            <p className="text-white/80 text-sm lg:text-lg font-medium leading-relaxed">সেরা ব্র্যান্ডের জ্যাকেট ও হুডি এখন পাচ্ছেন সাশ্রয়ী মূল্যে। ঘরে বসেই অর্ডার করুন।</p>
            <button 
              onClick={() => document.getElementById('featured')?.scrollIntoView({ behavior: 'smooth' })}
              className="bg-white text-primary font-bold px-8 py-3 rounded-2xl hover:bg-gray-100 transition-colors shadow-lg active:scale-95 transform transition-transform"
            >
              এখনই কিনুন
            </button>
          </div>
          <div className="absolute -right-10 -bottom-10 text-[180px] lg:text-[240px] opacity-10 select-none">❄️</div>
          <div className="absolute top-0 right-0 w-full h-full bg-gradient-to-l from-white/5 to-transparent pointer-events-none"></div>
        </div>
      </section>

      {/* Categories */}
      <section className="px-4 lg:px-0">
        <div className="flex items-center justify-between mb-6">
          <h3 className="font-black text-xl lg:text-2xl flex items-center gap-2">
            <span className="w-1.5 h-8 bg-primary rounded-full"></span>
            ক্যাটাগরি
          </h3>
          <button className="text-primary text-sm font-bold flex items-center hover:gap-1 transition-all">সব দেখুন <ChevronRight size={18} /></button>
        </div>
        <div className="grid grid-cols-3 sm:grid-cols-4 lg:grid-cols-6 gap-3 lg:gap-6">
          {categories.map((cat) => (
            <NavLink to={`/category/${cat.id}`} key={cat.id} className="group">
              <div className="bg-white aspect-square rounded-3xl shadow-sm border border-gray-100 flex flex-col items-center justify-center p-4 group-hover:border-primary/30 group-hover:shadow-lg transition-all duration-300">
                <div className="text-3xl lg:text-4xl mb-2 grayscale group-hover:grayscale-0 transition-all transform group-hover:scale-110">
                  {cat.id === 'clothing' ? '👗' : cat.id === 'electronics' ? '📱' : cat.id === 'food' ? '🍕' : cat.id === 'home' ? '🏠' : cat.id === 'beauty' ? '💄' : '🧸'}
                </div>
                <span className="text-[10px] lg:text-xs font-bold text-text-muted group-hover:text-primary transition-colors text-center">{cat.nameBn}</span>
              </div>
            </NavLink>
          ))}
        </div>
      </section>

      {/* Flash Sale */}
      {flashSaleProducts.length > 0 && (
        <section className="bg-orange-50 border-y border-orange-100 py-10 my-8 -mx-4 lg:-mx-0 lg:rounded-3xl lg:border-x">
          <div className="px-4 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 mb-8">
            <div className="flex items-center gap-3">
              <span className="text-3xl animate-bounce">⚡</span>
              <div>
                <h3 className="font-black text-xl text-secondary">ফ্ল্যাশ সেল চলছে</h3>
                <p className="text-[10px] text-orange-700 font-bold uppercase tracking-widest">সীমিত সময়ের অফার</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-2 font-mono text-white text-lg">
                <span className="bg-gray-800 px-3 py-1.5 rounded-xl shadow-lg">০২</span>
                <span className="text-gray-800 font-bold">:</span>
                <span className="bg-gray-800 px-3 py-1.5 rounded-xl shadow-lg">৪৫</span>
                <span className="text-gray-800 font-bold">:</span>
                <span className="bg-gray-800 px-3 py-1.5 rounded-xl shadow-lg">১২</span>
              </div>
            </div>
          </div>
          <div className="flex overflow-x-auto gap-4 no-scrollbar px-4 lg:px-8 pb-4">
            {flashSaleProducts.map((product) => (
              <ProductCard key={product.id} product={product} compact />
            ))}
          </div>
        </section>
      ) }

      {/* Featured Products */}
      <section id="featured" className="px-4 lg:px-0">
        <div className="flex items-center justify-between mb-6">
          <h3 className="font-black text-xl lg:text-2xl flex items-center gap-2">
            <span className="w-1.5 h-8 bg-primary rounded-full"></span>
            আপনার জন্য বাছাইকৃত
          </h3>
          <button className="text-primary text-sm font-bold">সব দেখুন</button>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 lg:gap-8">
          {featuredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      {/* Popular Products (Based on Views) */}
      {popularProducts.length > 0 && (
        <section className="px-4 lg:px-0 py-4">
          <div className="flex items-center justify-between mb-6">
            <h3 className="font-black text-xl lg:text-2xl flex items-center gap-2">
              <span className="w-1.5 h-8 bg-secondary rounded-full"></span>
              সবচেয়ে বেশি দেখা পন্য
            </h3>
            <span className="bg-secondary/10 text-secondary text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-widest">টপ চয়েস</span>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 lg:gap-8">
            {popularProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}

function ProductCard({ product, compact = false }: { product: Product, compact?: boolean, key?: any }) {
  const discount = product.salePrice ? Math.round(((product.price - product.salePrice) / product.price) * 100) : 0;

  return (
    <NavLink 
      to={`/product/${product.id}`}
      className={cn(
        "bg-white rounded-3xl overflow-hidden shadow-sm border border-gray-100 flex flex-col group hover:shadow-xl hover:shadow-primary/5 hover:border-primary/20 transition-all duration-300",
        compact ? "min-w-[160px] w-[160px]" : "w-full"
      )}
    >
      <div className="relative aspect-square bg-gray-50 overflow-hidden">
        <img 
          src={product.images[0]} 
          alt={product.name} 
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" 
        />
        {discount > 0 && (
          <div className="absolute top-3 left-3 bg-primary text-white text-[10px] font-black px-2.5 py-1 rounded-full shadow-lg shadow-primary/25">
            -{discount}% ছাড়
          </div>
        )}
        <button className="absolute bottom-3 right-3 w-10 h-10 bg-white/90 backdrop-blur shadow-lg rounded-full flex items-center justify-center text-primary transform translate-y-12 group-hover:translate-y-0 transition-transform duration-300 hover:bg-primary hover:text-white">
          <ShoppingCart size={18} />
        </button>
      </div>
      <div className="p-4 space-y-2">
        <div className="flex items-center gap-1">
          <div className="flex items-center">
            {[1,2,3,4,5].map(i => (
              <Star key={i} size={10} fill={i <= Math.round(product.rating) ? "#facc15" : "none"} className={i <= Math.round(product.rating) ? "text-yellow-400" : "text-gray-300"} />
            ))}
          </div>
          <span className="text-[10px] text-text-muted font-bold">({product.rating})</span>
        </div>
        <h4 className={cn("font-bold text-text-main line-clamp-2 leading-tight group-hover:text-primary transition-colors", compact ? "text-xs" : "text-sm")}>{product.nameBn}</h4>
        <div className="flex items-center gap-2 flex-wrap">
          <p className="text-primary font-black text-base">{formatPrice(product.salePrice || product.price)}</p>
          {product.salePrice && (
            <p className="text-[10px] text-text-muted line-through font-bold">{formatPrice(product.price)}</p>
          )}
        </div>
      </div>
    </NavLink>
  );
}
