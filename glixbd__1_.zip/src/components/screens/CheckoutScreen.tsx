import React, { useState, useMemo } from 'react';
import { useCart } from '@/src/lib/CartContext';
import { formatPrice, cn } from '@/src/lib/utils';
import { ShoppingBag, ChevronLeft, CreditCard, MapPin, ShieldCheck, ArrowRight, Truck, Wallet, CheckCircle2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { db, auth, OperationType, handleFirestoreError } from '@/src/lib/firebase';
import { divisions, districts, upazilas } from '@/src/lib/bangladesh-data';
import Confetti from 'react-confetti';
import useMeasure from 'react-use-measure';

export default function CheckoutScreen() {
  const { cart, subtotal, clearCart } = useCart();
  const navigate = useNavigate();
  const [measureRef, { width, height }] = useMeasure();
  const [isOrdered, setIsOrdered] = useState(false);
  const [loading, setLoading] = useState(false);
  const [orderNumber, setOrderNumber] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'cod' | 'bkash'>('cod');

  const [shippingInfo, setShippingInfo] = useState({
    fullName: auth.currentUser?.displayName || '',
    phone: '',
    division: '',
    divisionId: '',
    district: '',
    districtId: '',
    thana: '',
    thanaId: '',
    address: '',
    isDhaka: true
  });

  if (!auth.currentUser) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] p-8 text-center bg-white rounded-3xl shadow-xl shadow-gray-100 border border-gray-50 max-w-lg mx-auto my-10">
        <div className="w-20 h-20 bg-orange-50 text-orange-500 rounded-3xl flex items-center justify-center mb-6">
          <ShieldCheck size={40} />
        </div>
        <h2 className="text-2xl font-black text-text-main mb-4">অর্ডার করতে লগইন করুন</h2>
        <p className="text-text-muted mb-8 leading-relaxed">আপনার নিরাপত্তা এবং অর্ডার হিস্ট্রি সেভ করার জন্য চেকআউট করার আগে লগইন করা প্রয়োজন।</p>
        <button 
          onClick={() => navigate('/login', { state: { from: '/checkout' } })}
          className="w-full bg-primary text-white font-black py-4 rounded-2xl shadow-xl shadow-primary/20 active:scale-95 transition-all text-lg"
        >
          লগইন করুন
        </button>
      </div>
    );
  }

  const filteredDistricts = useMemo(() => {
    return districts.filter(d => d.division_id === shippingInfo.divisionId);
  }, [shippingInfo.divisionId]);

  const filteredUpazilas = useMemo(() => {
    return upazilas.filter(u => u.district_id === shippingInfo.districtId);
  }, [shippingInfo.districtId]);

  const deliveryCharge = shippingInfo.isDhaka ? 60 : 120;
  const total = subtotal + deliveryCharge;

  const handlePlaceOrder = async () => {
    if (cart.length === 0) return;
    
    if (!shippingInfo.fullName || !shippingInfo.phone || !shippingInfo.division || !shippingInfo.district || !shippingInfo.address) {
      alert('দয়া করে সব তথ্য পূরণ করুন।');
      return;
    }

    setLoading(true);
    try {
      const generatedOrderNum = `GBD-${Date.now().toString().slice(-8)}`;
      setOrderNumber(generatedOrderNum);

      const orderData = {
        orderNumber: generatedOrderNum,
        userId: auth.currentUser?.uid || 'guest',
        shippingAddress: shippingInfo,
        paymentMethod,
        subtotal,
        deliveryCharge,
        total,
        status: 'pending',
        createdAt: serverTimestamp(),
        items: cart
      };

      let orderRef;
      try {
        orderRef = await addDoc(collection(db, 'orders'), orderData);
      } catch (e) {
        handleFirestoreError(e, OperationType.CREATE, 'orders');
        return;
      }
      
      if (orderRef) {
        try {
          await addDoc(collection(db, `orders/${orderRef.id}/tracking`), {
            status: 'pending',
            statusBn: 'অর্ডার গৃহীত হয়েছে',
            message: 'Your order has been placed successfully.',
            messageBn: 'আপনার অর্ডারটি সফলভাবে গ্রহণ করা হয়েছে।',
            createdAt: serverTimestamp()
          });
        } catch (e) {
          handleFirestoreError(e, OperationType.CREATE, `orders/${orderRef.id}/tracking`);
        }
      }

      setIsOrdered(true);
      clearCart();
    } catch (error: any) {
      console.error("Checkout Failed:", error);
      alert('অর্ডার করতে সমস্যা হয়েছে। আবার চেষ্টা করুন।');
    } finally {
      setLoading(false);
    }
  };

  if (isOrdered) {
    return (
      <div ref={measureRef} className="flex flex-col items-center justify-center min-h-[80vh] p-8 text-center bg-white rounded-3xl shadow-xl shadow-gray-100 border border-gray-50 max-w-2xl mx-auto my-10 relative overflow-hidden">
        <Confetti width={width} height={height} recycle={false} numberOfPieces={300} />
        
        <motion.div 
          initial={{ scale: 0, rotate: -20 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{ type: 'spring', damping: 15 }}
          className="w-32 h-32 bg-green-50 text-green-500 rounded-[40px] flex items-center justify-center shadow-lg shadow-green-100 border-2 border-green-100"
        >
          <ShoppingBag size={56} strokeWidth={2.5} />
        </motion.div>

        <div className="space-y-4 max-w-sm">
          <motion.h2 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="text-3xl lg:text-4xl font-black text-text-main"
          >
            অর্ডার সফল হয়েছে!
          </motion.h2>
          <motion.div 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="bg-gray-50 p-4 rounded-3xl border border-dashed border-gray-200"
          >
            <p className="text-[10px] text-text-muted font-black uppercase tracking-[0.2em] mb-1">অর্ডার নম্বর</p>
            <p className="text-2xl font-black text-primary">{orderNumber}</p>
          </motion.div>
        </div>

        <motion.div 
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="flex flex-col sm:flex-row w-full gap-4 pt-8"
        >
          <button 
            onClick={() => navigate(`/tracking/${orderNumber}`)}
            className="flex-1 bg-primary text-white font-black py-5 rounded-3xl shadow-2xl shadow-primary/30 active:scale-95 transition-all text-lg hover:bg-primary/90"
          >
            অর্ডার ট্র্যাক করুন
          </button>
          <button 
            onClick={() => navigate('/')}
            className="flex-1 bg-gray-100 text-text-main font-black py-5 rounded-3xl active:scale-95 transition-all text-lg hover:bg-gray-200"
          >
            শপিং চালিয়ে যান
          </button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto pb-20 p-4 lg:p-0">
      <div className="flex items-center gap-4 mb-8">
        <button onClick={() => navigate(-1)} className="p-3 bg-white border border-gray-100 rounded-2xl shadow-sm hover:bg-gray-50">
          <ChevronLeft size={24} />
        </button>
        <h1 className="text-3xl lg:text-4xl font-black text-text-main">চেকআউট</h1>
      </div>

      <div className="lg:grid lg:grid-cols-12 lg:gap-12">
        <div className="lg:col-span-8 space-y-8">
          {/* Shipping Section */}
          <section className="bg-white p-8 lg:p-10 rounded-[40px] border border-gray-100 shadow-xl shadow-gray-100/50 space-y-8">
            <h3 className="text-xl font-black text-text-main flex items-center gap-3">
              <div className="w-1.5 h-6 bg-primary rounded-full"></div>
              শিপিং তথ্য দিন
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-xs font-black text-text-muted uppercase tracking-widest pl-2">পূর্ণ নাম</label>
                <input 
                  type="text" 
                  placeholder="আপনার নাম..." 
                  value={shippingInfo.fullName}
                  onChange={(e) => setShippingInfo({...shippingInfo, fullName: e.target.value})}
                  className="w-full bg-gray-50 border border-transparent focus:border-primary focus:bg-white outline-none px-6 py-4 rounded-3xl font-bold transition-all"
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-black text-text-muted uppercase tracking-widest pl-2">মোবাইল নম্বর</label>
                <input 
                  type="tel" 
                  placeholder="০১XXXXXXXXX" 
                  value={shippingInfo.phone}
                  onChange={(e) => setShippingInfo({...shippingInfo, phone: e.target.value})}
                  className="w-full bg-gray-50 border border-transparent focus:border-primary focus:bg-white outline-none px-6 py-4 rounded-3xl font-bold transition-all"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="space-y-2">
                <label className="text-xs font-black text-text-muted uppercase tracking-widest pl-2">বিভাগ</label>
                <div className="relative">
                  <select 
                    value={shippingInfo.divisionId}
                    onChange={(e) => {
                      const divId = e.target.value;
                      const div = divisions.find(d => d.id === divId);
                      setShippingInfo({
                        ...shippingInfo, 
                        divisionId: divId, 
                        division: div?.bn_name || '',
                        districtId: '',
                        district: '',
                        thanaId: '',
                        thana: '',
                        isDhaka: div?.bn_name === 'ঢাকা'
                      });
                    }}
                    className="w-full bg-gray-50 border border-transparent focus:border-primary focus:bg-white outline-none px-6 py-4 rounded-3xl font-bold transition-all appearance-none cursor-pointer"
                  >
                    <option value="">নির্বাচন করুন</option>
                    {divisions.map(d => <option key={d.id} value={d.id}>{d.bn_name}</option>)}
                  </select>
                  <div className="absolute right-6 top-1/2 -translate-y-1/2 pointer-events-none text-text-muted">
                    <ChevronLeft className="-rotate-90" size={16} />
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-black text-text-muted uppercase tracking-widest pl-2">জেলা</label>
                <div className="relative">
                  <select 
                    disabled={!shippingInfo.divisionId}
                    value={shippingInfo.districtId}
                    onChange={(e) => {
                      const distId = e.target.value;
                      const dist = districts.find(d => d.id === distId);
                      setShippingInfo({
                        ...shippingInfo, 
                        districtId: distId, 
                        district: dist?.bn_name || '',
                        thanaId: '',
                        thana: ''
                      });
                    }}
                    className="w-full bg-gray-50 border border-transparent focus:border-primary focus:bg-white outline-none px-6 py-4 rounded-3xl font-bold transition-all appearance-none cursor-pointer disabled:opacity-50"
                  >
                    <option value="">নির্বাচন করুন</option>
                    {filteredDistricts.map(d => <option key={d.id} value={d.id}>{d.bn_name}</option>)}
                  </select>
                  <div className="absolute right-6 top-1/2 -translate-y-1/2 pointer-events-none text-text-muted">
                    <ChevronLeft className="-rotate-90" size={16} />
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-black text-text-muted uppercase tracking-widest pl-2">থানা/উপজেলা</label>
                <div className="relative">
                  {filteredUpazilas.length > 0 ? (
                    <>
                      <select 
                        disabled={!shippingInfo.districtId}
                        value={shippingInfo.thanaId}
                        onChange={(e) => {
                          const tId = e.target.value;
                          const t = upazilas.find(u => u.id === tId);
                          setShippingInfo({
                            ...shippingInfo, 
                            thanaId: tId, 
                            thana: t?.bn_name || ''
                          });
                        }}
                        className="w-full bg-gray-50 border border-transparent focus:border-primary focus:bg-white outline-none px-6 py-4 rounded-3xl font-bold transition-all appearance-none cursor-pointer disabled:opacity-50"
                      >
                        <option value="">নির্বাচন করুন</option>
                        {filteredUpazilas.map(u => <option key={u.id} value={u.id}>{u.bn_name}</option>)}
                      </select>
                      <div className="absolute right-6 top-1/2 -translate-y-1/2 pointer-events-none text-text-muted">
                        <ChevronLeft className="-rotate-90" size={16} />
                      </div>
                    </>
                  ) : (
                    <input 
                      type="text" 
                      placeholder="থানা লিখুন..." 
                      disabled={!shippingInfo.districtId}
                      value={shippingInfo.thana}
                      onChange={(e) => setShippingInfo({...shippingInfo, thana: e.target.value})}
                      className="w-full bg-gray-50 border border-transparent focus:border-primary focus:bg-white outline-none px-6 py-4 rounded-3xl font-bold transition-all disabled:opacity-50"
                    />
                  )}
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-black text-text-muted uppercase tracking-widest pl-2">বিস্তারিত ঠিকানা</label>
              <textarea 
                placeholder="বাসা নম্বর, রোড বা বিস্তারিত..." 
                rows={3}
                value={shippingInfo.address}
                onChange={(e) => setShippingInfo({...shippingInfo, address: e.target.value})}
                className="w-full bg-gray-50 border border-transparent focus:border-primary focus:bg-white outline-none px-6 py-4 rounded-3xl font-bold transition-all resize-none"
              />
            </div>
          </section>

          {/* Payment Section */}
          <section className="bg-white p-8 lg:p-10 rounded-[40px] border border-gray-100 shadow-xl shadow-gray-100/50 space-y-8">
            <h3 className="text-xl font-black text-text-main flex items-center gap-3">
              <div className="w-1.5 h-6 bg-primary rounded-full"></div>
              পেমেন্ট পদ্ধতি
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <button 
                onClick={() => setPaymentMethod('cod')}
                className={cn(
                  "p-6 rounded-[32px] border-2 flex items-center gap-4 transition-all duration-300 relative group",
                  paymentMethod === 'cod' ? "border-primary bg-primary/[0.03] shadow-lg shadow-primary/10" : "border-gray-50 bg-gray-50 hover:border-gray-200"
                )}
              >
                <div className={cn(
                  "w-12 h-12 rounded-2xl flex items-center justify-center transition-colors",
                  paymentMethod === 'cod' ? "bg-primary text-white" : "bg-white text-gray-400 group-hover:text-primary"
                )}>
                  <Truck size={24} />
                </div>
                <div className="text-left">
                  <h4 className="font-black text-text-main">ক্যাশ অন ডেলিভারি</h4>
                  <p className="text-[10px] font-bold text-text-muted uppercase tracking-widest">পণ্য পেয়ে টাকা পরিশোধ</p>
                </div>
                {paymentMethod === 'cod' && (
                  <CheckCircle2 size={24} className="absolute top-4 right-4 text-primary" />
                )}
              </button>

              <button 
                onClick={() => setPaymentMethod('bkash')}
                className={cn(
                  "p-6 rounded-[32px] border-2 flex items-center gap-4 transition-all duration-300 relative group",
                  paymentMethod === 'bkash' ? "border-[#D12053] bg-[#D12053]/[0.03] shadow-lg shadow-[#D12053]/10" : "border-gray-50 bg-gray-50 hover:border-gray-200"
                )}
              >
                <div className={cn(
                  "w-12 h-12 rounded-2xl flex items-center justify-center transition-colors",
                  paymentMethod === 'bkash' ? "bg-[#D12053] text-white" : "bg-white text-gray-400 group-hover:text-[#D12053]"
                )}>
                  <Wallet size={24} />
                </div>
                <div className="text-left">
                  <h4 className="font-black text-text-main">বিকাশ পেমেন্ট</h4>
                  <p className="text-[10px] font-bold text-text-muted uppercase tracking-widest">ইনস্ট্যান্ট পেমেন্ট সুবিধা</p>
                </div>
                {paymentMethod === 'bkash' && (
                  <CheckCircle2 size={24} className="absolute top-4 right-4 text-[#D12053]" />
                )}
              </button>
            </div>
          </section>
        </div>

        <div className="lg:col-span-4 mt-8 lg:mt-0 space-y-6">
          <div className="bg-white p-8 rounded-[40px] border border-gray-100 shadow-2xl shadow-gray-200/40 space-y-8 sticky top-24">
            <h3 className="text-xl font-black text-text-main border-b border-gray-50 pb-6 flex items-center gap-3">
              <CreditCard size={24} className="text-primary" />
              অর্ডার সামারি
            </h3>

            <div className="space-y-4">
              <div className="flex justify-between font-bold text-text-muted">
                <span>উপমোট</span>
                <span>{formatPrice(subtotal)}</span>
              </div>
              <div className="flex justify-between font-bold text-text-muted">
                <span>ডেলিভারি চার্জ</span>
                <span>{formatPrice(deliveryCharge)}</span>
              </div>
              <div className="h-px bg-gray-50 w-full" />
              <div className="flex justify-between items-center pt-2">
                <span className="text-lg font-black">সর্বমোট</span>
                <span className="text-3xl font-black text-primary">{formatPrice(total)}</span>
              </div>
            </div>

            <div className="space-y-4 pt-4">
              <div className="flex items-center gap-3 text-[10px] text-text-muted font-black uppercase tracking-widest bg-gray-50 p-4 rounded-2xl">
                <ShieldCheck size={16} className="text-green-500" />
                আপনার পেমেন্ট সম্পূর্ণ সুরক্ষিত
              </div>

              <button 
                onClick={handlePlaceOrder}
                disabled={loading}
                className="w-full bg-primary text-white font-black py-5 rounded-[28px] shadow-2xl shadow-primary/30 flex items-center justify-center gap-3 active:scale-95 transition-all text-xl disabled:opacity-50 hover:bg-primary/90"
              >
                {loading ? (
                  <div className="w-6 h-6 border-4 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <>
                    অর্ডার নিশ্চিত করুন
                    <ArrowRight size={24} />
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
